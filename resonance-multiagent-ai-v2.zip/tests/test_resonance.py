
import numpy as np
from core.math.resonance_math import standing_wave, spectral_overlap

def test_self_overlap_close_to_one():
    t, s = standing_wave(n=4096, freq=3.0, dt=0.01, noise=0.0, seed=0)
    ov = spectral_overlap(s, s, dt=0.01)
    assert 0.99 <= ov <= 1.001
