
import argparse
import numpy as np
from core.math.resonance_math import spectral_overlap
from core.agents.resonance_agent import ResonanceAgent, ResonanceParams
from core.orchestrator import ResonanceOrchestrator, OrchestratorConfig
from applications.medical_research.target_function import target_signal

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=150)
    ap.add_argument("--agents", type=int, default=4)
    ap.add_argument("--freq", type=float, default=3.0)
    ap.add_argument("--dt", type=float, default=0.01)
    ap.add_argument("--noise", type=float, default=0.05)
    args = ap.parse_args()

    t, target = target_signal(n=4096, dt=args.dt, base_freq=args.freq, noise=0.02)
    agents = []
    for i in range(args.agents):
        params = ResonanceParams(freq=args.freq * (0.5 + 0.5*(i+1)/args.agents), dt=args.dt, noise=args.noise)
        agents.append(ResonanceAgent(name=f"agent_{i+1}", target_signal=target, params=params, seed=100+i))

    orch = ResonanceOrchestrator(agents, cfg=OrchestratorConfig(steps=args.steps))
    hist = orch.run(context={})
    last = hist[-1]
    print("Mean resonance:", f"{last['mean_resonance']:.4f}", "Approved:", last["approved"])
    for out in last["agents"]:
        print(out["agent"], "score:", f"{out['score']:.4f}")

if __name__ == "__main__":
    main()
