
"""Синтетическая целевая функция 'здоровая жизнь' как сигнал (для демо)."""
import numpy as np

def target_signal(n=4096, dt=0.01, base_freq=3.0, harmonics=(2, 3), noise=0.02, seed=42):
    rng = np.random.default_rng(seed)
    t = np.arange(n) * dt
    s = np.cos(2*np.pi*base_freq*t)
    for k in harmonics:
        s += (1.0/k) * np.cos(2*np.pi*base_freq*k*t + 0.1*k)
    s += noise * rng.normal(size=n)
    return t, s
