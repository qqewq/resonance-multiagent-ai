
from fastapi import FastAPI
from pydantic import BaseModel
from applications.medical_research.target_function import target_signal
from core.agents.resonance_agent import ResonanceAgent, ResonanceParams
from core.orchestrator import ResonanceOrchestrator, OrchestratorConfig

app = FastAPI(title="Resonance Multi-Agent API")

class RunRequest(BaseModel):
    steps: int = 120
    agents: int = 4
    base_freq: float = 3.0
    dt: float = 0.01
    noise: float = 0.05

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/resonance")
def run(req: RunRequest):
    _, target = target_signal(n=4096, dt=req.dt, base_freq=req.base_freq, noise=0.02)
    agents = []
    for i in range(req.agents):
        p = ResonanceParams(freq=req.base_freq * (0.5 + 0.5*(i+1)/req.agents), dt=req.dt, noise=req.noise)
        agents.append(ResonanceAgent(name=f"agent_{i+1}", target_signal=target, params=p, seed=100+i))

    orch = ResonanceOrchestrator(agents, cfg=OrchestratorConfig(steps=req.steps))
    hist = orch.run(context={})
    last = hist[-1]
    # compact response
    return {
        "mean_resonance": last["mean_resonance"],
        "approved": last["approved"],
        "agents": [{"name": r["agent"], "score": r["score"]} for r in last["agents"]],
        "attention": last["collective"]["attention"],
        "collective_score": last["collective"]["collective_score"]
    }
