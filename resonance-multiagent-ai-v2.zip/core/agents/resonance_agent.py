
from dataclasses import dataclass
import numpy as np
from .base_agent import BaseAgent
from ..math.resonance_math import standing_wave, spectral_overlap

@dataclass
class ResonanceParams:
    freq: float = 2.0
    dt: float = 0.01
    noise: float = 0.05

class ResonanceAgent(BaseAgent):
    def __init__(self, name: str, target_signal, params: ResonanceParams | None = None, seed: int = 0):
        super().__init__(name)
        self.params = params or ResonanceParams()
        self.target = np.asarray(target_signal, dtype=float)
        self.rng = np.random.default_rng(seed)

    def propose(self):
        n = len(self.target)
        # варьируем частоту на небольшой случайный мультипликатор
        jitter = 1.0 + 0.02 * self.rng.normal()
        freq = max(0.1, self.params.freq * jitter)
        t, x = standing_wave(n=n, dt=self.params.dt, freq=freq, noise=self.params.noise, seed=self.state.step)
        self.state.info["freq"] = freq
        return x

    def evaluate(self, context: dict) -> float:
        cand = context["candidate"]
        score = spectral_overlap(cand, self.target, dt=self.params.dt)
        # простейшее "обучение": двигать частоту к более высоким оценкам
        if "last_score" in self.state.info:
            if score >= self.state.info["last_score"]:
                self.params.freq *= 1.01
            else:
                self.params.freq *= 0.99
        self.state.info["last_score"] = score
        return float(score)
