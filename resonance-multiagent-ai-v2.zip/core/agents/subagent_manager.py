
from typing import List
from .base_agent import BaseAgent

class SubagentManager:
    def __init__(self, agents: List[BaseAgent]):
        self.agents = list(agents)

    def step_all(self, context: dict):
        results = []
        for a in self.agents:
            results.append(a.step(context))
        return results

    def names(self):
        return [a.state.name for a in self.agents]
