
from dataclasses import dataclass
from typing import Any, Dict

@dataclass
class AgentState:
    name: str
    step: int = 0
    info: Dict[str, Any] = None

class BaseAgent:
    def __init__(self, name: str):
        self.state = AgentState(name=name, step=0, info={})

    def propose(self):
        """Вернуть кандидат (гипотезу/сигнал)."""
        raise NotImplementedError

    def evaluate(self, context: dict) -> float:
        """Оценить кандидата в текущем контексте (резонанс, полезность и т.д.)."""
        raise NotImplementedError

    def step(self, context: dict) -> dict:
        """Один цикл работы агента: propose -> evaluate -> update."""
        cand = self.propose()
        score = self.evaluate({**context, "candidate": cand})
        self.state.step += 1
        return {"agent": self.state.name, "candidate": cand, "score": score}
