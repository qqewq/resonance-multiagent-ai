
from dataclasses import dataclass
from typing import List, Dict, Any
import numpy as np
from .agents.base_agent import BaseAgent
from .agents.subagent_manager import SubagentManager
from .math.ethics import EthicalFilter
from .interaction import AgentInteractionNetwork

@dataclass
class OrchestratorConfig:
    steps: int = 100

class ResonanceOrchestrator:
    def __init__(self, agents: List[BaseAgent], ethics: EthicalFilter | None = None, cfg: OrchestratorConfig | None = None):
        self.manager = SubagentManager(agents)
        self.ethics = ethics or EthicalFilter()
        self.cfg = cfg or OrchestratorConfig()
        self.history: List[Dict[str, Any]] = []
        self.interaction = AgentInteractionNetwork()

    def run(self, context: Dict[str, Any]):
        for _ in range(self.cfg.steps):
            outs = self.manager.step_all(context)
            inter = self.interaction.aggregate(outs)
            mean_res = float(np.mean([o["score"] for o in outs]))
            ethics_score = 0.7  # заглушка
            approved = self.ethics.approve(mean_res, ethics_score)
            self.history.append({
                "agents": outs,
                "collective": inter,
                "mean_resonance": mean_res,
                "approved": approved
            })
        return self.history
