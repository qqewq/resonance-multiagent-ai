
"""Механизмы взаимодействия: упрощённое 'внимание' и сеть взаимодействий."""
import numpy as np

class AttentionMechanism:
    def __init__(self, temperature: float = 0.7):
        self.temperature = max(1e-6, float(temperature))

    def weights(self, scores):
        s = np.asarray(scores, dtype=float)
        s = s / max(1e-9, s.std() + 1e-9)  # normalize
        exps = np.exp(s / self.temperature)
        w = exps / (np.sum(exps) + 1e-12)
        return w

class AgentInteractionNetwork:
    def aggregate(self, agent_outputs):
        scores = [r["score"] for r in agent_outputs]
        attn = AttentionMechanism().weights(scores)
        # взвешенная сумма как "коллективное мнение"
        collective = float(np.sum(attn * np.asarray(scores)))
        return {"collective_score": collective, "attention": attn.tolist()}
