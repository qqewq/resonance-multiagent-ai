
"""FFT-метрики и генерация тестовых сигналов (standing wave)."""
import numpy as np

def standing_wave(n=2048, freq=3.0, dt=0.01, amplitude=1.0, noise=0.0, seed=0):
    rng = np.random.default_rng(seed)
    t = np.arange(n) * dt
    s = amplitude * np.cos(2*np.pi*freq*t)
    if noise > 0:
        s += noise * rng.normal(size=n)
    return t, s

def fft_spectrum(x, dt=1.0):
    x = np.asarray(x, dtype=float)
    n = x.size
    freqs = np.fft.rfftfreq(n, d=dt)
    spec = np.fft.rfft(x) / n
    power = (spec.real**2 + spec.imag**2)
    return freqs, power

def spectral_overlap(x, y, dt=1.0):
    fx, px = fft_spectrum(x, dt)
    fy, py = fft_spectrum(y, dt)
    m = min(len(px), len(py))
    px, py = px[:m], py[:m]
    num = np.sum(np.sqrt(px * py))
    den = (np.sqrt(np.sum(px)) * np.sqrt(np.sum(py)) + 1e-12)
    return float(np.clip(num / den, 0.0, 1.0))
